$ErrorActionPreference = 'Stop'
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -U pip
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver 0.0.0.0:8000
