# F1 Academy – Proyecto Django listo para usar

## Cómo arrancar (rápido)
**Linux/macOS**
```bash
./run.sh
```
**Windows PowerShell**
```powershell
.un.ps1
```

Luego abre http://127.0.0.1:8000/ — verás:
- **Videos** (catálogo demo)
- **Usuarios** (tabla demo)
- **Créditos**

## Integración a un proyecto existente
- Copia `templates/` y `static/` a tu proyecto.
- Instala la app `courses` y agrega en `INSTALLED_APPS`.
- En `urls.py` del proyecto: `path('', include('courses.urls'))`.
