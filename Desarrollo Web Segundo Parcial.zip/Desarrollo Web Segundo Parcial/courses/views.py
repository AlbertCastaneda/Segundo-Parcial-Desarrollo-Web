from django.shortcuts import render

def videos(request):
    sample = [
        {
            'title': 'Aerodinámica básica',
            'description': 'Downforce, drag y efecto suelo.',
            'embed_url': 'https://www.youtube.com/embed/rrv9UXxKrbo',  # ✅ formato embed
            'level': 1,
            'duration': '12:34'
        },
        {
            'title': 'Pit Stops Pro',
            'description': 'Estrategias, neumáticos y sincronización.',
            'embed_url': 'https://www.youtube.com/embed/vlUUrrwcUQw',  # ✅ formato embed
            'level': 2,
            'duration': '08:21'
        },
        {
            'title': 'Telemetría',
            'description': 'Canales clave y análisis de datos.',
            'embed_url': 'https://www.youtube.com/embed/n7z2eTt7Ku0',  # ✅ shorts convertido a embed
            'level': 1,
            'duration': '10:05'
        },
    ]
    return render(request, 'pages/videos.html', {'videos': sample})


def usuarios(request):
    alumnos = [
        {
            'nombre': 'Albert Castaneda',
            'email': 'albert.castaneda@miumg.com',
            'pais': 'GT',
            'curso': 'Aerodinámica',
            'estado': 'Activo'
        },
        {
            'nombre': 'Iván de Leon',
            'email': 'ivan.leon@miumg.com',
            'pais': 'GT',
            'curso': 'Telemetría',
            'estado': 'Pendiente'
        },
    ]
    return render(request, 'pages/usuarios.html', {'usuarios': alumnos})


def creditos(request):
    return render(request, 'pages/creditos.html')
